
// Name- Gayatri Subhalaxmi, Roll no.-18121
// Singly linked list ; and reverse it



#include <stdio.h>  
   
//For a node 
  
struct node{  
    int data;  
    struct node *previous;  
    struct node *next;  
};      
   
//for the head and tail 
struct node *head, *tail = NULL;  
   
//addNode() for adding a node to the list  
void addNode(int data) {  
    //Creating a new node  
    struct node *newNode = (struct node*)malloc(sizeof(struct node));  
    newNode->data = data;  
      
    /*=>If list is empty, both head and tail will point to newNode ,head's previous will point to NULL and tail's next will point to NULL, as it is the last node of the list
    or else =>newNode will be added after tail such that tail's next will point to newNode. Then newNode's previous will point to tail and newNode will become new tail. As it is last node, tail's next will point to NULL*/
    if(head == NULL) {  
        head = tail = newNode;
        head->previous = NULL;  
        tail->next = NULL;  
    }  
    else {  
        tail->next = newNode;  
        newNode->previous = tail;  
        tail = newNode;  
        tail->next = NULL;  
    }  
}  
   
//for counting no. of nodes in the list  
int countNodes() {  
    int counter = 0;  
    //Node current will point to head  
    struct node *current = head;  
      
    while(current != NULL) {  
        //Increment the counter by 1 for each node  
        counter++;  
        current = current->next;  
    }  
    return counter;  
}  
      
//for printing out the nodes of the list  
void display() {  
    //Node current will point to head  
    struct node *current = head;  
    if(head == NULL) {  
        printf("List is empty\n");  
        return;  
    }  
    printf("Nodes of doubly linked list: \n");  
    while(current != NULL) {  
        //nodes after incrementing pointer.  
        printf("%d ", current->data);  
        current = current->next;  
    }  
}  
   
int main()  
{  
    //for adding nodes to the list
    addNode(1);  
    addNode(15);  
    addNode(3);  
    addNode(67);  
    addNode(5);
    addNode(16);
    addNode(12); 
    addNode(18);
    addNode(25); 
      
      
    display();  
      
    //Counting the nodes present in the given list  
    printf("\nCount of nodes present in the list: %d", countNodes());  
   
    return 0;  
}  



/*
* In singly linked list the complexity of insertion and deletion at a known position is O(n). But In case od doubly linked list the complexity of insertion and deletion at a known position is O(1).
* In singly linked list implementation is such as where the node contains some data and a pointer to the next node in the list while doubly linked list has some more complex implementation where the node contains some data and a pointer to the next as well as the previous node in the list.
* Singly linked list allows traversal elements only in one way. But doubly linked list allows element two way traversal.
* Singly linked list are generally used for implementation of stacks. On other hand doubly linked list can be used to implement stacks as well as heaps and binary trees.
* Singly linked list is preferred when we need to save memory and searching is not required as pointer of single index is stored. If we need better performance while searching and memory is not a limitation in this case doubly linked list is more preferred.
* As singly linked list store pointer of only one node so consumes lesser memory. On other hand Doubly linked list uses more memory per node(two pointers).

* Advantages of ddl:

1. We can traverse in both directions i.e. from starting to end and as well as from end to starting.
2. It is easy to reverse the linked list.
3. If we are at a node, then we can go to any node. But in linear linked list, it is not possible to reach the previous node.

* Disadvantages of ddl:

1. It requires more space per space per node because one extra field is required for pointer to previous node.
2. Insertion and deletion take more time than linear linked list because more pointer operations are required than linear linked list.*/

/******************************************************************************
Gayatri Subhalaxmi
18121
Q2
Endsem

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
#include <string.h>
/* Using‘heapify’ function to heapify the subtree 
with node ‘i’ which is an index in array[ ]*/
void heapify(int array[], int m, int i)
{
int largest = i;
int k = 2 * i + 1;
int v = 2 * i + 2;
/*If the left child is larger than the root, 
largest root equals to 1*/
if (k < m && array[k] > array[largest])
largest = k;

/*if the right child is larger than the largest root then 
largest equals to ‘v’*/
if (v < m && array[v] > array[largest])
largest = v;

if (largest != i)
/* If largest is not root 
then we swap the values
and recursively heapify the affected sub- tree using the same heapify function. */
{
int temp = array[i];
array[i]= array[largest];
array[largest] = temp;
heapify(array, m, largest);
}
}
/*Defining a function to build max-heap*/
void buildHeap(int array[], int m)
{
    /*define the last non- leaf 
node and then we perform the reverse order traversal from the last non- leaf
node and heapify each node using heapify function*/
int startIdx = (m / 2) - 1;
for (int i = startIdx; i >= 0; i--) {
heapify(array, m, i);
}
}
/*defining ‘printHeap’ function to print the array representation of the heap*/
void printHeap(int array[], int m)
{
printf("The array representation of Heap is:\n");
for (int i = 0; i < m; ++i)
printf("%d \n",array[i]);
}
int Comp(const void* one, const void* two)
{
return strcmp(*(const char**)one, *(const char**)two);
}
int main()
{
    const char* array_name[]= { "Gayatri", "Banu", "Sofee", "Mami", "Tanistha" };
int s = sizeof(array_name) / sizeof(array_name[0]);
qsort(array_name, s, sizeof(const char*), Comp);
int array[6];
printf("The sorted names are: \n");
for (int key = 0; key < s; key++)
{
printf("%s \n", array_name[key]);
array[key]=key;
}
array_name[s]="Shishira";
printf("%s \n", array_name[s]);
array[s]=s;
int m = sizeof(array) / sizeof(array[0]);
buildHeap(array, m); // applied the previously defined function
printHeap(array, m);
return 0;
}

/*
OUTPUT

define the last non- leaf 
node and then we perform the reverse order traversal from the last non- leaf
node and heapify each node using heapify function

*/

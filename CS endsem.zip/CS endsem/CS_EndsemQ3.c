/******************************************************************************

                            Gayatri Subhalaxmi
                            Roll no. 18121
                            Q3
                            CS endsem
*******************************************************************************/
/******************************************************************************

******************************************************************************/



#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//Defining Binary search tree node
struct node
{
	int key;
	struct node *left, *right;
};

struct node* newNode(int item)
{
/* 
nodes are sorted in ascending order from left to right
     y in left of x ⇒ key[y]  key[x]

*/
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->key = item;
    temp->left = temp->right = NULL;
    return temp;
}
/******************************************************************************
For Shorting in ascending order from left to right;

******************************************************************************/

void inorder(struct node* root)
{
    if (root != NULL)
    {    
        inorder(root->left);
        printf("%d ", root->key);
        inorder(root->right);
    }
}
/******************************************************************************
For Insertion;

******************************************************************************/

struct node* insert(struct node* node, int key)
{
    if (node == NULL)
        return newNode(key);
    if(key < node->key)
        node->left = insert(node->left,key);
    else
        node->right = insert(node->right,key);
    return node;
}

struct node* minValueNode(struct node* node)
{
    struct node* current = node;
    while (current && current->left != NULL)
        current = current->left;    
    return current;
}

/******************************************************************************
For Deletion;
~Starting at the root,
~Searching the deepest and rightmost node in binary tree and node which we want to delete. 
~Replacing the deepest rightmost node’s data with the node to be deleted. 
~Then delete the deepest rightmost node.
******************************************************************************/
struct node* deleteNode(struct node* root, int key)
{
    //base case
    if (root == NULL)
        return root;
 
    //If the key to be deleted is smaller than the root's key, it lies in left subtree
    if (key < root->key)
        root->left = deleteNode(root->left, key);
 
    //If the key to be deleted is greater than the root's key, it lies in right subtree
    else if (key > root->key)
        root->right = deleteNode(root->right, key);
 
    //If key is same as root's key, then this is the node to be deleted
    else 
	{
        //Node with only one child or no child:
        if (root->left == NULL)
		{
            struct node* temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
		{
            struct node* temp = root->left;
            free(root);
            return temp;
        }

        //Node with two children:
        //Get the inorder successor (smallest in the right subtree)
        struct node* temp = minValueNode(root->right);
 
        //Copy the inorder successor's content to this node
        root->key = temp->key;
 
        //Delete the inorder successor
        root->right = deleteNode(root->right, temp->key);
    }
    return root;
}

//Compare function
void sort(char arr1[][10], int n, int i, int j)
{   
    char temp[10];    
	for(i = 0; i < n; i++)
    for(j = i + 1; j < n; j++)
    { 
        if(strcmp(arr1[i],arr1[j]) > 0)
        {
            strcpy(temp,arr1[i]);
            strcpy(arr1[i],arr1[j]);
            strcpy(arr1[j],temp);
        }
    }
}

void hash(char arr1[][10], int *arr, int s, int key)
{   
    //Gives hash value key + 1 to the names 
    for (key = 0; key < s; key++)
        arr[key]=key + 1;
    
    //Making other places in the array as 0
    for(key = s+1; key < 10;key++)
        arr[key]= 0;
}

int main()
{
    //Storing names in array for a list
    char arr1[6][10]= { "Gayatri", "Banu", "Sofee", "Mami", "Tanistha" };
    int s = 6;
    int i, j;
    
    //Sorting the names array by sending Comp as argument using sort function
    sort(arr1, s, i, j);
    int arr[10];
    int key;
    
   //Hash function called
	hash(arr1, arr, s, key);
	
	//Printing and indexing the sorted names along with their hash values
	printf("Sorted names:\t Hash value: \n");
	for(key = 0; key < s; key++)
		printf("%s with index %d \n", arr1[key], arr[key]);
		
    int n = 6;
    struct node *root = NULL;
    for (i = 0; i < n; i++)
        root = insert(root, arr[i]);

	printf("Inorder traversal of the constructed binary search tree is: ");
	inorder(root);
    printf("\n Enter the index of the name you want to delete: ");
    scanf("%d", &j);
	root = deleteNode(root, j);
	printf("\n Inorder traversal after deletion of %d is: ", j);
	inorder(root);
    printf("\n");
	return 0; 
    }

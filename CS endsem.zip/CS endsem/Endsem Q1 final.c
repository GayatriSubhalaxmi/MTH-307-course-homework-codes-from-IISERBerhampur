/******************************************************************************

                            Gayatri Subhalaxmi
                            Roll no.18121
From an array of strings with your name and another five of your friends'. 
Choose and explain a criteria of your choice for comparison to arrange the array in ascending order.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
#include<string.h>

static int arrange(const void*p1,const void*p2){
    return strcmp(*(const char**)p1,*(const char**)p2);
} 
/* Here we are defining a built-in library function declared in <string.h>
called strcmp 
that returns <,0,> depending on comparison between two strings characters
*/


main()
{
    //Declaring array of strings with my name and another five of my friends
    const char *arr[] = { "Gayatri", "Banu", "Sofee", "Mami", "Tanistha" };
    int i, j,n;
    int size = 5; //sizeof (arr)/sizeof (arr[0]);
    
    printf ("size of the array is %d\n", size);
    for (i = 0; i < size; i++){
        printf ("Names taken are %d:%s\n", i, arr[i]);
        
    }
    /*
    For sorting the array in required arrangement we are using qsort function
    that return value meaning
    <0 The element pointed by p1 goes before the element pointed by p2
    0  The element pointed by p1 is equivalent to the element pointed by p2
    >0 The element pointed by p1 goes after the element pointed by p2
    */
    qsort(arr,size,sizeof(const char*), arrange);
    
     printf("\n The required array in ascending order arrangement:\n");
    for (i = 0; i < size; i++){
        printf ("Names taken are %d:%s\n", i, arr[i]);
        
    }
   
        

    return 0;
}
/*
OUTPUT:

size of the array is 5
Names taken are 0:Gayatri
Names taken are 1:Banu
Names taken are 2:Sofee
Names taken are 3:Mami
Names taken are 4:Tanistha

 The required array in ascending order arrangement:
Names taken are 0:Banu
Names taken are 1:Gayatri
Names taken are 2:Mami
Names taken are 3:Sofee
Names taken are 4:Tanistha

*/
